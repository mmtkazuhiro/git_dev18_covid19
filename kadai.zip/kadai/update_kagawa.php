<?php

require_once('funcs.php');

//1. POSTデータ取得
    $kagawa_infected = $_POST['kagawa_infected'];
    $kagawa_injured = $_POST['kagawa_injured'];
    $kagawa_bed = $_POST['kagawa_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        kagawa_infected = :kagawa_infected,
                        kagawa_injured = :kagawa_injured,
                        kagawa_bed = :kagawa_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':kagawa_infected', $kagawa_infected, PDO::PARAM_INT); 
$stmt->bindValue(':kagawa_injured', $kagawa_injured, PDO::PARAM_INT);
$stmt->bindValue(':kagawa_bed', $kagawa_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('kagawa.php');
}
