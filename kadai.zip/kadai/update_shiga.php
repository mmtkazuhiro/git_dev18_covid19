<?php

require_once('funcs.php');

//1. POSTデータ取得
    $shiga_infected = $_POST['shiga_infected'];
    $shiga_injured = $_POST['shiga_injured'];
    $shiga_bed = $_POST['shiga_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        shiga_infected = :shiga_infected,
                        shiga_injured = :shiga_injured,
                        shiga_bed = :shiga_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':shiga_infected', $shiga_infected, PDO::PARAM_INT); 
$stmt->bindValue(':shiga_injured', $shiga_injured, PDO::PARAM_INT);
$stmt->bindValue(':shiga_bed', $shiga_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('shiga.php');
}
