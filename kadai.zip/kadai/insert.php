<?php

    require_once('funcs.php');

    $hokkaido_infected = $_POST['hokkaido_infected'];
    $hokkaido_injured = $_POST['hokkaido_injured'];
    $hokkaido_bed = $_POST['hokkaido_bed'];

    $aomori_infected = $_POST['aomori_infected'];
    $aomori_injured = $_POST['aomori_injured'];
    $aomori_bed = $_POST['aomori_bed'];

    $iwate_infected = $_POST['iwate_infected'];
    $iwate_injured = $_POST['iwate_injured'];
    $iwate_bed = $_POST['iwate_bed'];

    $miyagi_infected = $_POST['miyagi_infected'];
    $miyagi_injured = $_POST['miyagi_injured'];
    $miyagi_bed = $_POST['miyagi_bed'];

    $akita_infected = $_POST['akita_infected'];
    $akita_injured = $_POST['akita_injured'];
    $akita_bed = $_POST['akita_bed'];

    $yamagata_infected = $_POST['yamagata_infected'];
    $yamagata_injured = $_POST['yamagata_injured'];
    $yamagata_bed = $_POST['yamagata_bed'];

    $fukushima_infected = $_POST['fukushima_infected'];
    $fukushima_injured = $_POST['fukushima_injured'];
    $fukushima_bed = $_POST['fukushima_bed'];

    $ibaraki_infected = $_POST['ibaraki_infected'];
    $ibaraki_injured = $_POST['ibaraki_injured'];
    $ibaraki_bed = $_POST['ibaraki_bed'];

    $tochigi_infected = $_POST['tochigi_infected'];
    $tochigi_injured = $_POST['tochigi_injured'];
    $tochigi_bed = $_POST['tochigi_bed'];

    $gunma_infected = $_POST['gunma_infected'];
    $gunma_injured = $_POST['gunma_injured'];
    $gunma_bed = $_POST['gunma_bed'];

    $saitama_infected = $_POST['saitama_infected'];
    $saitama_injured = $_POST['saitama_injured'];
    $saitama_bed = $_POST['saitama_bed'];

    $chiba_infected = $_POST['chiba_infected'];
    $chiba_injured = $_POST['chiba_injured'];
    $chiba_bed = $_POST['chiba_bed'];

    $tokyo_infected = $_POST['tokyo_infected'];
    $tokyo_injured = $_POST['tokyo_injured'];
    $tokyo_bed = $_POST['tokyo_bed'];

    $kanagawa_infected = $_POST['kanagawa_infected'];
    $kanagawa_injured = $_POST['kanagawa_injured'];
    $kanagawa_bed = $_POST['kanagawa_bed'];

    $niigata_infected = $_POST['niigata_infected'];
    $niigata_injured = $_POST['niigata_injured'];
    $niigata_bed = $_POST['niigata_bed'];

    $toyama_infected = $_POST['toyama_infected'];
    $toyama_injured = $_POST['toyama_injured'];
    $toyama_bed = $_POST['toyama_bed'];

    $ishikawa_infected = $_POST['ishikawa_infected'];
    $ishikawa_injured = $_POST['ishikawa_injured'];
    $ishikawa_bed = $_POST['ishikawa_bed'];

    $fukui_infected = $_POST['fukui_infected'];
    $fukui_injured = $_POST['fukui_injured'];
    $fukui_bed = $_POST['fukui_bed'];

    $yamanashi_infected = $_POST['yamanashi_infected'];
    $yamanashi_injured = $_POST['yamanashi_injured'];
    $yamanashi_bed = $_POST['yamanashi_bed'];

    $nagano_infected = $_POST['nagano_infected'];
    $nagano_injured = $_POST['nagano_injured'];
    $nagano_bed = $_POST['nagano_bed'];

    $gifu_infected = $_POST['gifu_infected'];
    $gifu_injured = $_POST['gifu_injured'];
    $gifu_bed = $_POST['gifu_bed'];

    $shizuoka_infected = $_POST['shizuoka_infected'];
    $shizuoka_injured = $_POST['shizuoka_injured'];
    $shizuoka_bed = $_POST['shizuoka_bed'];

    $aichi_infected = $_POST['aichi_infected'];
    $aichi_injured = $_POST['aichi_injured'];
    $aichi_bed = $_POST['aichi_bed'];

    $mie_infected = $_POST['mie_infected'];
    $mie_injured = $_POST['mie_injured'];
    $mie_bed = $_POST['mie_bed'];

    $shiga_infected = $_POST['shiga_infected'];
    $shiga_injured = $_POST['shiga_injured'];
    $shiga_bed = $_POST['shiga_bed'];

    $kyoto_infected = $_POST['kyoto_infected'];
    $kyoto_injured = $_POST['kyoto_injured'];
    $kyoto_bed = $_POST['kyoto_bed'];

    $osaka_infected = $_POST['osaka_infected'];
    $osaka_injured = $_POST['osaka_injured'];
    $osaka_bed = $_POST['osaka_bed'];

    $hyogo_infected = $_POST['hyogo_infected'];
    $hyogo_injured = $_POST['hyogo_injured'];
    $hyogo_bed = $_POST['hyogo_bed'];

    $nara_infected = $_POST['nara_infected'];
    $nara_injured = $_POST['nara_injured'];
    $nara_bed = $_POST['nara_bed'];

    $wakayama_infected = $_POST['wakayama_infected'];
    $wakayama_injured = $_POST['wakayama_injured'];
    $wakayama_bed = $_POST['wakayama_bed'];

    $tottori_infected = $_POST['tottori_infected'];
    $tottori_injured = $_POST['tottori_injured'];
    $tottori_bed = $_POST['tottori_bed'];

    $shimane_infected = $_POST['shimane_infected'];
    $shimane_injured = $_POST['shimane_injured'];
    $shimane_bed = $_POST['shimane_bed'];

    $okayama_infected = $_POST['okayama_infected'];
    $okayama_injured = $_POST['okayama_injured'];
    $okayama_bed = $_POST['okayama_bed'];

    $hiroshima_infected = $_POST['hiroshima_infected'];
    $hiroshima_injured = $_POST['hiroshima_injured'];
    $hiroshima_bed = $_POST['hiroshima_bed'];

    $yamaguchi_infected = $_POST['yamaguchi_infected'];
    $yamaguchi_injured = $_POST['yamaguchi_injured'];
    $yamaguchi_bed = $_POST['yamaguchi_bed'];

    $tokushima_infected = $_POST['tokushima_infected'];
    $tokushima_injured = $_POST['tokushima_injured'];
    $tokushima_bed = $_POST['tokushima_bed'];

    $kagawa_infected = $_POST['kagawa_infected'];
    $kagawa_injured = $_POST['kagawa_injured'];
    $kagawa_bed = $_POST['kagawa_bed'];

    $ehime_infected = $_POST['ehime_infected'];
    $ehime_injured = $_POST['ehime_injured'];
    $ehime_bed = $_POST['ehime_bed'];

    $kochi_infected = $_POST['kochi_infected'];
    $kochi_injured = $_POST['kochi_injured'];
    $kochi_bed = $_POST['kochi_bed'];

    $fukuoka_infected = $_POST['fukuoka_infected'];
    $fukuoka_injured = $_POST['fukuoka_injured'];
    $fukuoka_bed = $_POST['fukuoka_bed'];

    $saga_infected = $_POST['saga_infected'];
    $saga_injured = $_POST['saga_injured'];
    $saga_bed = $_POST['saga_bed'];

    $nagasaki_infected = $_POST['nagasaki_infected'];
    $nagasaki_injured = $_POST['nagasaki_injured'];
    $nagasaki_bed = $_POST['nagasaki_bed'];

    $kumamoto_infected = $_POST['kumamoto_infected'];
    $kumamoto_injured = $_POST['kumamoto_injured'];
    $kumamoto_bed = $_POST['kumamoto_bed'];

    $oita_infected = $_POST['oita_infected'];
    $oita_injured = $_POST['oita_injured'];
    $oita_bed = $_POST['oita_bed'];

    $miyazaki_infected = $_POST['miyazaki_infected'];
    $miyazaki_injured = $_POST['miyazaki_injured'];
    $miyazaki_bed = $_POST['miyazaki_bed'];

    $kagoshima_infected = $_POST['kagoshima_infected'];
    $kagoshima_injured = $_POST['kagoshima_injured'];
    $kagoshima_bed = $_POST['kagoshima_bed'];

    $okinawa_infected = $_POST['okinawa_infected'];
    $okinawa_injured = $_POST['okinawa_injured'];
    $okinawa_bed = $_POST['okinawa_bed'];

    // DB接続
    $pdo = db_conn();

    $stmt = $pdo->prepare("INSERT INTO 
                    gs_c_table(
                        hokkaido_infected,
                        hokkaido_injured,
                        hokkaido_bed,

                        aomori_infected,
                        aomori_injured,
                        aomori_bed,

                        iwate_infected,
                        iwate_injured,
                        iwate_bed,

                        miyagi_infected,
                        miyagi_injured,
                        miyagi_bed,

                        akita_infected,
                        akita_injured,
                        akita_bed,

                        yamagata_infected,
                        yamagata_injured,
                        yamagata_bed,

                        fukushima_infected,
                        fukushima_injured,
                        fukushima_bed,

                        ibaraki_infected,
                        ibaraki_injured,
                        ibaraki_bed,

                        tochigi_infected,
                        tochigi_injured,
                        tochigi_bed,

                        gunma_infected,
                        gunma_injured,
                        gunma_bed,

                        saitama_infected,
                        saitama_injured,
                        saitama_bed,

                        chiba_infected,
                        chiba_injured,
                        chiba_bed,

                        tokyo_infected,
                        tokyo_injured,
                        tokyo_bed,

                        kanagawa_infected,
                        kanagawa_injured,
                        kanagawa_bed,

                        niigata_infected,
                        niigata_injured,
                        niigata_bed,

                        toyama_infected,
                        toyama_injured,
                        toyama_bed,

                        ishikawa_infected,
                        ishikawa_injured,
                        ishikawa_bed,

                        fukui_infected,
                        fukui_injured,
                        fukui_bed,

                        yamanashi_infected,
                        yamanashi_injured,
                        yamanashi_bed,

                        nagano_infected,
                        nagano_injured,
                        nagano_bed,

                        gifu_infected,
                        gifu_injured,
                        gifu_bed,

                        shizuoka_infected,
                        shizuoka_injured,
                        shizuoka_bed,

                        aichi_infected,
                        aichi_injured,
                        aichi_bed,

                        mie_infected,
                        mie_injured,
                        mie_bed,
                        
                        shiga_infected,
                        shiga_injured,
                        shiga_bed,

                        kyoto_infected,
                        kyoto_injured,
                        kyoto_bed,

                        osaka_infected,
                        osaka_injured,
                        osaka_bed,

                        hyogo_infected,
                        hyogo_injured,
                        hyogo_bed,

                        nara_infected,
                        nara_injured,
                        nara_bed,

                        wakayama_infected,
                        wakayama_injured,
                        wakayama_bed,

                        tottori_infected,
                        tottori_injured,
                        tottori_bed,

                        shimane_infected,
                        shimane_injured,
                        shimane_bed,

                        okayama_infected,
                        okayama_injured,
                        okayama_bed,

                        hiroshima_infected,
                        hiroshima_injured,
                        hiroshima_bed,

                        yamaguchi_infected,
                        yamaguchi_injured,
                        yamaguchi_bed,

                        tokushima_infected,
                        tokushima_injured,
                        tokushima_bed,

                        kagawa_infected,
                        kagawa_injured,
                        kagawa_bed,

                        ehime_infected,
                        ehime_injured,
                        ehime_bed,

                        kochi_infected,
                        kochi_injured,
                        kochi_bed,

                        fukuoka_infected,
                        fukuoka_injured,
                        fukuoka_bed,

                        saga_infected,
                        saga_injured,
                        saga_bed,

                        nagasaki_infected,
                        nagasaki_injured,
                        nagasaki_bed,

                        kumamoto_infected,
                        kumamoto_injured,
                        kumamoto_bed,

                        oita_infected,
                        oita_injured,
                        oita_bed,

                        miyazaki_infected,
                        miyazaki_injured,
                        miyazaki_bed,

                        kagoshima_infected,
                        kagoshima_injured,
                        kagoshima_bed,

                        okinawa_infected,
                        okinawa_injured,
                        okinawa_bed,
                        
                        indate)
                    VALUES(
                        :hokkaido_infected,
                        :hokkaido_injured,
                        :hokkaido_bed,

                        :aomori_infected,
                        :aomori_injured,
                        :aomori_bed,

                        :iwate_infected,
                        :iwate_injured,
                        :iwate_bed,

                        :miyagi_infected,
                        :miyagi_injured,
                        :miyagi_bed,

                        :akita_infected,
                        :akita_injured,
                        :akita_bed,

                        :yamagata_infected,
                        :yamagata_injured,
                        :yamagata_bed,

                        :fukushima_infected,
                        :fukushima_injured,
                        :fukushima_bed,

                        :ibaraki_infected,
                        :ibaraki_injured,
                        :ibaraki_bed,

                        :tochigi_infected,
                        :tochigi_injured,
                        :tochigi_bed,

                        :gunma_infected,
                        :gunma_injured,
                        :gunma_bed,

                        :saitama_infected,
                        :saitama_injured,
                        :saitama_bed,

                        :chiba_infected,
                        :chiba_injured,
                        :chiba_bed,

                        :tokyo_infected,
                        :tokyo_injured,
                        :tokyo_bed,

                        :kanagawa_infected,
                        :kanagawa_injured,
                        :kanagawa_bed,

                        :niigata_infected,
                        :niigata_injured,
                        :niigata_bed,

                        :toyama_infected,
                        :toyama_injured,
                        :toyama_bed,

                        :ishikawa_infected,
                        :ishikawa_injured,
                        :ishikawa_bed,

                        :fukui_infected,
                        :fukui_injured,
                        :fukui_bed,

                        :yamanashi_infected,
                        :yamanashi_injured,
                        :yamanashi_bed,

                        :nagano_infected,
                        :nagano_injured,
                        :nagano_bed,

                        :gifu_infected,
                        :gifu_injured,
                        :gifu_bed,

                        :shizuoka_infected,
                        :shizuoka_injured,
                        :shizuoka_bed,

                        :aichi_infected,
                        :aichi_injured,
                        :aichi_bed,

                        :mie_infected,
                        :mie_injured,
                        :mie_bed,

                        :shiga_infected,
                        :shiga_injured,
                        :shiga_bed,

                        :kyoto_infected,
                        :kyoto_injured,
                        :kyoto_bed,

                        :osaka_infected,
                        :osaka_injured,
                        :osaka_bed,

                        :hyogo_infected,
                        :hyogo_injured,
                        :hyogo_bed,

                        :nara_infected,
                        :nara_injured,
                        :nara_bed,

                        :wakayama_infected,
                        :wakayama_injured,
                        :wakayama_bed,

                        :tottori_infected,
                        :tottori_injured,
                        :tottori_bed,

                        :shimane_infected,
                        :shimane_injured,
                        :shimane_bed,

                        :okayama_infected,
                        :okayama_injured,
                        :okayama_bed,

                        :hiroshima_infected,
                        :hiroshima_injured,
                        :hiroshima_bed,

                        :yamaguchi_infected,
                        :yamaguchi_injured,
                        :yamaguchi_bed,

                        :tokushima_infected,
                        :tokushima_injured,
                        :tokushima_bed,

                        :kagawa_infected,
                        :kagawa_injured,
                        :kagawa_bed,

                        :ehime_infected,
                        :ehime_injured,
                        :ehime_bed,

                        :kochi_infected,
                        :kochi_injured,
                        :kochi_bed,

                        :fukuoka_infected,
                        :fukuoka_injured,
                        :fukuoka_bed,

                        :saga_infected,
                        :saga_injured,
                        :saga_bed,

                        :nagasaki_infected,
                        :nagasaki_injured,
                        :nagasaki_bed,

                        :kumamoto_infected,
                        :kumamoto_injured,
                        :kumamoto_bed,

                        :oita_infected,
                        :oita_injured,
                        :oita_bed,

                        :miyazaki_infected,
                        :miyazaki_injured,
                        :miyazaki_bed,

                        :kagoshima_infected,
                        :kagoshima_injured,
                        :kagoshima_bed,

                        :okinawa_infected,
                        :okinawa_injured,
                        :okinawa_bed,

                        sysdate())");

    $stmt->bindValue(':hokkaido_infected', $hokkaido_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':hokkaido_injured', $hokkaido_injured, PDO::PARAM_INT);
    $stmt->bindValue(':hokkaido_bed', $hokkaido_bed, PDO::PARAM_INT);

    $stmt->bindValue(':aomori_infected', $aomori_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':aomori_injured', $aomori_injured, PDO::PARAM_INT);
    $stmt->bindValue(':aomori_bed', $aomori_bed, PDO::PARAM_INT);

    $stmt->bindValue(':iwate_infected', $iwate_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':iwate_injured', $iwate_injured, PDO::PARAM_INT);
    $stmt->bindValue(':iwate_bed', $iwate_bed, PDO::PARAM_INT);

    $stmt->bindValue(':miyagi_infected', $miyagi_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':miyagi_injured', $miyagi_injured, PDO::PARAM_INT);
    $stmt->bindValue(':miyagi_bed', $miyagi_bed, PDO::PARAM_INT);

    $stmt->bindValue(':akita_infected', $akita_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':akita_injured', $akita_injured, PDO::PARAM_INT);
    $stmt->bindValue(':akita_bed', $akita_bed, PDO::PARAM_INT);

    $stmt->bindValue(':yamagata_infected', $yamagata_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':yamagata_injured', $yamagata_injured, PDO::PARAM_INT);
    $stmt->bindValue(':yamagata_bed', $yamagata_bed, PDO::PARAM_INT);

    $stmt->bindValue(':fukushima_infected', $fukushima_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':fukushima_injured', $fukushima_injured, PDO::PARAM_INT);
    $stmt->bindValue(':fukushima_bed', $fukushima_bed, PDO::PARAM_INT);

    $stmt->bindValue(':ibaraki_infected', $ibaraki_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':ibaraki_injured', $ibaraki_injured, PDO::PARAM_INT);
    $stmt->bindValue(':ibaraki_bed', $ibaraki_bed, PDO::PARAM_INT);

    $stmt->bindValue(':tochigi_infected', $tochigi_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':tochigi_injured', $tochigi_injured, PDO::PARAM_INT);
    $stmt->bindValue(':tochigi_bed', $tochigi_bed, PDO::PARAM_INT);

    $stmt->bindValue(':gunma_infected', $gunma_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':gunma_injured', $gunma_injured, PDO::PARAM_INT);
    $stmt->bindValue(':gunma_bed', $gunma_bed, PDO::PARAM_INT);

    $stmt->bindValue(':saitama_infected', $saitama_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':saitama_injured', $saitama_injured, PDO::PARAM_INT);
    $stmt->bindValue(':saitama_bed', $saitama_bed, PDO::PARAM_INT);

    $stmt->bindValue(':chiba_infected', $chiba_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':chiba_injured', $chiba_injured, PDO::PARAM_INT);
    $stmt->bindValue(':chiba_bed', $chiba_bed, PDO::PARAM_INT);

    $stmt->bindValue(':tokyo_infected', $tokyo_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':tokyo_injured', $tokyo_injured, PDO::PARAM_INT);
    $stmt->bindValue(':tokyo_bed', $tokyo_bed, PDO::PARAM_INT);

    $stmt->bindValue(':kanagawa_infected', $kanagawa_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':kanagawa_injured', $kanagawa_injured, PDO::PARAM_INT);
    $stmt->bindValue(':kanagawa_bed', $kanagawa_bed, PDO::PARAM_INT);

    $stmt->bindValue(':niigata_infected', $niigata_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':niigata_injured', $niigata_injured, PDO::PARAM_INT);
    $stmt->bindValue(':niigata_bed', $niigata_bed, PDO::PARAM_INT);

    $stmt->bindValue(':toyama_infected', $toyama_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':toyama_injured', $toyama_injured, PDO::PARAM_INT);
    $stmt->bindValue(':toyama_bed', $toyama_bed, PDO::PARAM_INT);

    $stmt->bindValue(':ishikawa_infected', $ishikawa_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':ishikawa_injured', $ishikawa_injured, PDO::PARAM_INT);
    $stmt->bindValue(':ishikawa_bed', $ishikawa_bed, PDO::PARAM_INT);

    $stmt->bindValue(':fukui_infected', $fukui_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':fukui_injured', $fukui_injured, PDO::PARAM_INT);
    $stmt->bindValue(':fukui_bed', $fukui_bed, PDO::PARAM_INT);

    $stmt->bindValue(':yamanashi_infected', $yamanashi_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':yamanashi_injured', $yamanashi_injured, PDO::PARAM_INT);
    $stmt->bindValue(':yamanashi_bed', $yamanashi_bed, PDO::PARAM_INT);

    $stmt->bindValue(':nagano_infected', $nagano_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':nagano_injured', $nagano_injured, PDO::PARAM_INT);
    $stmt->bindValue(':nagano_bed', $nagano_bed, PDO::PARAM_INT);

    $stmt->bindValue(':gifu_infected', $gifu_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':gifu_injured', $gifu_injured, PDO::PARAM_INT);
    $stmt->bindValue(':gifu_bed', $gifu_bed, PDO::PARAM_INT);

    $stmt->bindValue(':shizuoka_infected', $shizuoka_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':shizuoka_injured', $shizuoka_injured, PDO::PARAM_INT);
    $stmt->bindValue(':shizuoka_bed', $shizuoka_bed, PDO::PARAM_INT);

    $stmt->bindValue(':aichi_infected', $aichi_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':aichi_injured', $aichi_injured, PDO::PARAM_INT);
    $stmt->bindValue(':aichi_bed', $aichi_bed, PDO::PARAM_INT);

    $stmt->bindValue(':mie_infected', $mie_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':mie_injured', $mie_injured, PDO::PARAM_INT);
    $stmt->bindValue(':mie_bed', $mie_bed, PDO::PARAM_INT);

    $stmt->bindValue(':shiga_infected', $shiga_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':shiga_injured', $shiga_injured, PDO::PARAM_INT);
    $stmt->bindValue(':shiga_bed', $shiga_bed, PDO::PARAM_INT);

    $stmt->bindValue(':kyoto_infected', $kyoto_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':kyoto_injured', $kyoto_injured, PDO::PARAM_INT);
    $stmt->bindValue(':kyoto_bed', $kyoto_bed, PDO::PARAM_INT);

    $stmt->bindValue(':osaka_infected', $osaka_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':osaka_injured', $osaka_injured, PDO::PARAM_INT);
    $stmt->bindValue(':osaka_bed', $osaka_bed, PDO::PARAM_INT);

    $stmt->bindValue(':hyogo_infected', $hyogo_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':hyogo_injured', $hyogo_injured, PDO::PARAM_INT);
    $stmt->bindValue(':hyogo_bed', $hyogo_bed, PDO::PARAM_INT);

    $stmt->bindValue(':nara_infected', $nara_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':nara_injured', $nara_injured, PDO::PARAM_INT);
    $stmt->bindValue(':nara_bed', $nara_bed, PDO::PARAM_INT);

    $stmt->bindValue(':wakayama_infected', $wakayama_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':wakayama_injured', $wakayama_injured, PDO::PARAM_INT);
    $stmt->bindValue(':wakayama_bed', $wakayama_bed, PDO::PARAM_INT);

    $stmt->bindValue(':tottori_infected', $tottori_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':tottori_injured', $tottori_injured, PDO::PARAM_INT);
    $stmt->bindValue(':tottori_bed', $tottori_bed, PDO::PARAM_INT);

    $stmt->bindValue(':shimane_infected', $shimane_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':shimane_injured', $shimane_injured, PDO::PARAM_INT);
    $stmt->bindValue(':shimane_bed', $shimane_bed, PDO::PARAM_INT);

    $stmt->bindValue(':okayama_infected', $okayama_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':okayama_injured', $okayama_injured, PDO::PARAM_INT);
    $stmt->bindValue(':okayama_bed', $okayama_bed, PDO::PARAM_INT);

    $stmt->bindValue(':hiroshima_infected', $hiroshima_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':hiroshima_injured', $hiroshima_injured, PDO::PARAM_INT);
    $stmt->bindValue(':hiroshima_bed', $hiroshima_bed, PDO::PARAM_INT);

    $stmt->bindValue(':yamaguchi_infected', $yamaguchi_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':yamaguchi_injured', $yamaguchi_injured, PDO::PARAM_INT);
    $stmt->bindValue(':yamaguchi_bed', $yamaguchi_bed, PDO::PARAM_INT);

    $stmt->bindValue(':tokushima_infected', $tokushima_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':tokushima_injured', $tokushima_injured, PDO::PARAM_INT);
    $stmt->bindValue(':tokushima_bed', $tokushima_bed, PDO::PARAM_INT);

    $stmt->bindValue(':kagawa_infected', $kagawa_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':kagawa_injured', $kagawa_injured, PDO::PARAM_INT);
    $stmt->bindValue(':kagawa_bed', $kagawa_bed, PDO::PARAM_INT);

    $stmt->bindValue(':ehime_infected', $ehime_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':ehime_injured', $ehime_injured, PDO::PARAM_INT);
    $stmt->bindValue(':ehime_bed', $ehime_bed, PDO::PARAM_INT);

    $stmt->bindValue(':kochi_infected', $kochi_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':kochi_injured', $kochi_injured, PDO::PARAM_INT);
    $stmt->bindValue(':kochi_bed', $kochi_bed, PDO::PARAM_INT);

    $stmt->bindValue(':fukuoka_infected', $fukuoka_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':fukuoka_injured', $fukuoka_injured, PDO::PARAM_INT);
    $stmt->bindValue(':fukuoka_bed', $fukuoka_bed, PDO::PARAM_INT);

    $stmt->bindValue(':saga_infected', $saga_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':saga_injured', $saga_injured, PDO::PARAM_INT);
    $stmt->bindValue(':saga_bed', $saga_bed, PDO::PARAM_INT);

    $stmt->bindValue(':nagasaki_infected', $nagasaki_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':nagasaki_injured', $nagasaki_injured, PDO::PARAM_INT);
    $stmt->bindValue(':nagasaki_bed', $nagasaki_bed, PDO::PARAM_INT);

    $stmt->bindValue(':kumamoto_infected', $kumamoto_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':kumamoto_injured', $kumamoto_injured, PDO::PARAM_INT);
    $stmt->bindValue(':kumamoto_bed', $kumamoto_bed, PDO::PARAM_INT);

    $stmt->bindValue(':oita_infected', $oita_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':oita_injured', $oita_injured, PDO::PARAM_INT);
    $stmt->bindValue(':oita_bed', $oita_bed, PDO::PARAM_INT);

    $stmt->bindValue(':miyazaki_infected', $miyazaki_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':miyazaki_injured', $miyazaki_injured, PDO::PARAM_INT);
    $stmt->bindValue(':miyazaki_bed', $miyazaki_bed, PDO::PARAM_INT);

    $stmt->bindValue(':kagoshima_infected', $kagoshima_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':kagoshima_injured', $kagoshima_injured, PDO::PARAM_INT);
    $stmt->bindValue(':kagoshima_bed', $kagoshima_bed, PDO::PARAM_INT);

    $stmt->bindValue(':okinawa_infected', $okinawa_infected, PDO::PARAM_INT); 
    $stmt->bindValue(':okinawa_injured', $okinawa_injured, PDO::PARAM_INT);
    $stmt->bindValue(':okinawa_bed', $okinawa_bed, PDO::PARAM_INT);

    $status = $stmt->execute();


if ($status == false) {
    // funcs.phpで関数化したsql_errorを使う
    sql_error($stmt);

} else {
    redirect('select.php');
}