<?php

require_once('funcs.php');

//1. POSTデータ取得
    $tokushima_infected = $_POST['tokushima_infected'];
    $tokushima_injured = $_POST['tokushima_injured'];
    $tokushima_bed = $_POST['tokushima_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        tokushima_infected = :tokushima_infected,
                        tokushima_injured = :tokushima_injured,
                        tokushima_bed = :tokushima_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':tokushima_infected', $tokushima_infected, PDO::PARAM_INT); 
$stmt->bindValue(':tokushima_injured', $tokushima_injured, PDO::PARAM_INT);
$stmt->bindValue(':tokushima_bed', $tokushima_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('tokushima.php');
}
