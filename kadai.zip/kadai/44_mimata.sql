-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:3306
-- 生成日時: 2021 年 1 月 15 日 12:55
-- サーバのバージョン： 5.7.30
-- PHP のバージョン: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- データベース: `gs_kadai2`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_c_table`
--

CREATE TABLE `gs_c_table` (
  `id` int(12) NOT NULL,
  `hokkaido_infected` int(11) NOT NULL,
  `hokkaido_injured` int(11) NOT NULL,
  `hokkaido_bed` int(11) NOT NULL,
  `aomori_infected` int(11) NOT NULL,
  `aomori_injured` int(11) NOT NULL,
  `aomori_bed` int(11) NOT NULL,
  `iwate_infected` int(11) NOT NULL,
  `iwate_injured` int(11) NOT NULL,
  `iwate_bed` int(11) NOT NULL,
  `miyagi_infected` int(11) NOT NULL,
  `miyagi_injured` int(11) NOT NULL,
  `miyagi_bed` int(11) NOT NULL,
  `akita_infected` int(11) NOT NULL,
  `akita_injured` int(11) NOT NULL,
  `akita_bed` int(11) NOT NULL,
  `yamagata_infected` int(11) NOT NULL,
  `yamagata_injured` int(11) NOT NULL,
  `yamagata_bed` int(11) NOT NULL,
  `fukushima_infected` int(11) NOT NULL,
  `fukushima_injured` int(11) NOT NULL,
  `fukushima_bed` int(11) NOT NULL,
  `ibaraki_infected` int(11) NOT NULL,
  `ibaraki_injured` int(11) NOT NULL,
  `ibaraki_bed` int(11) NOT NULL,
  `tochigi_infected` int(11) NOT NULL,
  `tochigi_injured` int(11) NOT NULL,
  `tochigi_bed` int(11) NOT NULL,
  `gunma_infected` int(11) NOT NULL,
  `gunma_injured` int(11) NOT NULL,
  `gunma_bed` int(11) NOT NULL,
  `saitama_infected` int(11) NOT NULL,
  `saitama_injured` int(11) NOT NULL,
  `saitama_bed` int(11) NOT NULL,
  `chiba_infected` int(11) NOT NULL,
  `chiba_injured` int(11) NOT NULL,
  `chiba_bed` int(11) NOT NULL,
  `tokyo_infected` int(11) NOT NULL,
  `tokyo_injured` int(11) NOT NULL,
  `tokyo_bed` int(11) NOT NULL,
  `kanagawa_infected` int(11) NOT NULL,
  `kanagawa_injured` int(11) NOT NULL,
  `kanagawa_bed` int(11) NOT NULL,
  `niigata_infected` int(11) NOT NULL,
  `niigata_injured` int(11) NOT NULL,
  `niigata_bed` int(11) NOT NULL,
  `toyama_infected` int(11) NOT NULL,
  `toyama_injured` int(11) NOT NULL,
  `toyama_bed` int(11) NOT NULL,
  `ishikawa_infected` int(11) NOT NULL,
  `ishikawa_injured` int(11) NOT NULL,
  `ishikawa_bed` int(11) NOT NULL,
  `fukui_infected` int(11) NOT NULL,
  `fukui_injured` int(11) NOT NULL,
  `fukui_bed` int(11) NOT NULL,
  `yamanashi_infected` int(11) NOT NULL,
  `yamanashi_injured` int(11) NOT NULL,
  `yamanashi_bed` int(11) NOT NULL,
  `nagano_infected` int(11) NOT NULL,
  `nagano_injured` int(11) NOT NULL,
  `nagano_bed` int(11) NOT NULL,
  `gifu_infected` int(11) NOT NULL,
  `gifu_injured` int(11) NOT NULL,
  `gifu_bed` int(11) NOT NULL,
  `shizuoka_infected` int(11) NOT NULL,
  `shizuoka_injured` int(11) NOT NULL,
  `shizuoka_bed` int(11) NOT NULL,
  `aichi_infected` int(11) NOT NULL,
  `aichi_injured` int(11) NOT NULL,
  `aichi_bed` int(11) NOT NULL,
  `mie_infected` int(11) NOT NULL,
  `mie_injured` int(11) NOT NULL,
  `mie_bed` int(11) NOT NULL,
  `shiga_infected` int(11) NOT NULL,
  `shiga_injured` int(11) NOT NULL,
  `shiga_bed` int(11) NOT NULL,
  `kyoto_infected` int(11) NOT NULL,
  `kyoto_injured` int(11) NOT NULL,
  `kyoto_bed` int(11) NOT NULL,
  `osaka_infected` int(11) NOT NULL,
  `osaka_injured` int(11) NOT NULL,
  `osaka_bed` int(11) NOT NULL,
  `hyogo_infected` int(11) NOT NULL,
  `hyogo_injured` int(11) NOT NULL,
  `hyogo_bed` int(11) NOT NULL,
  `nara_infected` int(11) NOT NULL,
  `nara_injured` int(11) NOT NULL,
  `nara_bed` int(11) NOT NULL,
  `wakayama_infected` int(11) NOT NULL,
  `wakayama_injured` int(11) NOT NULL,
  `wakayama_bed` int(11) NOT NULL,
  `tottori_infected` int(11) NOT NULL,
  `tottori_injured` int(11) NOT NULL,
  `tottori_bed` int(11) NOT NULL,
  `shimane_infected` int(11) NOT NULL,
  `shimane_injured` int(11) NOT NULL,
  `shimane_bed` int(11) NOT NULL,
  `okayama_infected` int(11) NOT NULL,
  `okayama_injured` int(11) NOT NULL,
  `okayama_bed` int(11) NOT NULL,
  `hiroshima_infected` int(11) NOT NULL,
  `hiroshima_injured` int(11) NOT NULL,
  `hiroshima_bed` int(11) NOT NULL,
  `yamaguchi_infected` int(11) NOT NULL,
  `yamaguchi_injured` int(11) NOT NULL,
  `yamaguchi_bed` int(11) NOT NULL,
  `tokushima_infected` int(11) NOT NULL,
  `tokushima_injured` int(11) NOT NULL,
  `tokushima_bed` int(11) NOT NULL,
  `kagawa_infected` int(11) NOT NULL,
  `kagawa_injured` int(11) NOT NULL,
  `kagawa_bed` int(11) NOT NULL,
  `ehime_infected` int(11) NOT NULL,
  `ehime_injured` int(11) NOT NULL,
  `ehime_bed` int(11) NOT NULL,
  `kochi_infected` int(11) NOT NULL,
  `kochi_injured` int(11) NOT NULL,
  `kochi_bed` int(11) NOT NULL,
  `fukuoka_infected` int(11) NOT NULL,
  `fukuoka_injured` int(11) NOT NULL,
  `fukuoka_bed` int(11) NOT NULL,
  `saga_infected` int(11) NOT NULL,
  `saga_injured` int(11) NOT NULL,
  `saga_bed` int(11) NOT NULL,
  `nagasaki_infected` int(11) NOT NULL,
  `nagasaki_injured` int(11) NOT NULL,
  `nagasaki_bed` int(11) NOT NULL,
  `kumamoto_infected` int(11) NOT NULL,
  `kumamoto_injured` int(11) NOT NULL,
  `kumamoto_bed` int(11) NOT NULL,
  `oita_infected` int(11) NOT NULL,
  `oita_injured` int(11) NOT NULL,
  `oita_bed` int(11) NOT NULL,
  `miyazaki_infected` int(11) NOT NULL,
  `miyazaki_injured` int(11) NOT NULL,
  `miyazaki_bed` int(11) NOT NULL,
  `kagoshima_infected` int(11) NOT NULL,
  `kagoshima_injured` int(11) NOT NULL,
  `kagoshima_bed` int(11) NOT NULL,
  `okinawa_infected` int(11) NOT NULL,
  `okinawa_injured` int(11) NOT NULL,
  `okinawa_bed` int(11) NOT NULL,
  `indate` datetime NOT NULL,
  `fix` varchar(64) NOT NULL DEFAULT '訂正',
  `del` varchar(64) NOT NULL DEFAULT '削除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `gs_c_table`
--

INSERT INTO `gs_c_table` (`id`, `hokkaido_infected`, `hokkaido_injured`, `hokkaido_bed`, `aomori_infected`, `aomori_injured`, `aomori_bed`, `iwate_infected`, `iwate_injured`, `iwate_bed`, `miyagi_infected`, `miyagi_injured`, `miyagi_bed`, `akita_infected`, `akita_injured`, `akita_bed`, `yamagata_infected`, `yamagata_injured`, `yamagata_bed`, `fukushima_infected`, `fukushima_injured`, `fukushima_bed`, `ibaraki_infected`, `ibaraki_injured`, `ibaraki_bed`, `tochigi_infected`, `tochigi_injured`, `tochigi_bed`, `gunma_infected`, `gunma_injured`, `gunma_bed`, `saitama_infected`, `saitama_injured`, `saitama_bed`, `chiba_infected`, `chiba_injured`, `chiba_bed`, `tokyo_infected`, `tokyo_injured`, `tokyo_bed`, `kanagawa_infected`, `kanagawa_injured`, `kanagawa_bed`, `niigata_infected`, `niigata_injured`, `niigata_bed`, `toyama_infected`, `toyama_injured`, `toyama_bed`, `ishikawa_infected`, `ishikawa_injured`, `ishikawa_bed`, `fukui_infected`, `fukui_injured`, `fukui_bed`, `yamanashi_infected`, `yamanashi_injured`, `yamanashi_bed`, `nagano_infected`, `nagano_injured`, `nagano_bed`, `gifu_infected`, `gifu_injured`, `gifu_bed`, `shizuoka_infected`, `shizuoka_injured`, `shizuoka_bed`, `aichi_infected`, `aichi_injured`, `aichi_bed`, `mie_infected`, `mie_injured`, `mie_bed`, `shiga_infected`, `shiga_injured`, `shiga_bed`, `kyoto_infected`, `kyoto_injured`, `kyoto_bed`, `osaka_infected`, `osaka_injured`, `osaka_bed`, `hyogo_infected`, `hyogo_injured`, `hyogo_bed`, `nara_infected`, `nara_injured`, `nara_bed`, `wakayama_infected`, `wakayama_injured`, `wakayama_bed`, `tottori_infected`, `tottori_injured`, `tottori_bed`, `shimane_infected`, `shimane_injured`, `shimane_bed`, `okayama_infected`, `okayama_injured`, `okayama_bed`, `hiroshima_infected`, `hiroshima_injured`, `hiroshima_bed`, `yamaguchi_infected`, `yamaguchi_injured`, `yamaguchi_bed`, `tokushima_infected`, `tokushima_injured`, `tokushima_bed`, `kagawa_infected`, `kagawa_injured`, `kagawa_bed`, `ehime_infected`, `ehime_injured`, `ehime_bed`, `kochi_infected`, `kochi_injured`, `kochi_bed`, `fukuoka_infected`, `fukuoka_injured`, `fukuoka_bed`, `saga_infected`, `saga_injured`, `saga_bed`, `nagasaki_infected`, `nagasaki_injured`, `nagasaki_bed`, `kumamoto_infected`, `kumamoto_injured`, `kumamoto_bed`, `oita_infected`, `oita_injured`, `oita_bed`, `miyazaki_infected`, `miyazaki_injured`, `miyazaki_bed`, `kagoshima_infected`, `kagoshima_injured`, `kagoshima_bed`, `okinawa_infected`, `okinawa_injured`, `okinawa_bed`, `indate`, `fix`, `del`) VALUES
(8, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 20, 21, 21, 21, 22, 22, 22, 23, 23, 23, 24, 24, 24, 25, 25, 25, 26, 26, 26, 27, 27, 27, 28, 28, 28, 29, 29, 29, 30, 30, 30, 31, 31, 31, 32, 32, 32, 33, 33, 33, 34, 34, 34, 35, 35, 35, 36, 36, 36, 37, 37, 37, 38, 38, 38, 39, 39, 39, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, '2021-01-12 00:00:00', '訂正', '削除'),
(10, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-12 23:09:34', '訂正', '削除'),
(12, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-12 23:17:03', '訂正', '削除'),
(15, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-12 23:18:10', '訂正', '削除'),
(17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-13 01:06:24', '訂正', '削除'),
(18, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-13 10:24:58', '訂正', '削除'),
(19, 1, 2, 3, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-13 12:02:32', '訂正', '削除'),
(20, 1, 2, 3, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-13 12:02:57', '訂正', '削除'),
(21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-13 13:23:52', '訂正', '削除'),
(22, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 838, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-13 17:38:49', '訂正', '削除'),
(23, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, '2021-01-13 21:03:18', '訂正', '削除'),
(24, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-14 20:22:45', '訂正', '削除'),
(25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-14 20:25:08', '訂正', '削除'),
(26, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-14 20:29:42', '訂正', '削除'),
(27, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-14 20:30:00', '訂正', '削除'),
(28, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-01-14 20:30:09', '訂正', '削除');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `gs_c_table`
--
ALTER TABLE `gs_c_table`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルのAUTO_INCREMENT
--

--
-- テーブルのAUTO_INCREMENT `gs_c_table`
--
ALTER TABLE `gs_c_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;