<?php

require_once('funcs.php');

//1. POSTデータ取得
    $nagano_infected = $_POST['nagano_infected'];
    $nagano_injured = $_POST['nagano_injured'];
    $nagano_bed = $_POST['nagano_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        nagano_infected = :nagano_infected,
                        nagano_injured = :nagano_injured,
                        nagano_bed = :nagano_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':nagano_infected', $nagano_infected, PDO::PARAM_INT); 
$stmt->bindValue(':nagano_injured', $nagano_injured, PDO::PARAM_INT);
$stmt->bindValue(':nagano_bed', $nagano_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('nagano.php');
}
