<?php

require_once('funcs.php');

//1. POSTデータ取得
    $toyama_infected = $_POST['toyama_infected'];
    $toyama_injured = $_POST['toyama_injured'];
    $toyama_bed = $_POST['toyama_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        toyama_infected = :toyama_infected,
                        toyama_injured = :toyama_injured,
                        toyama_bed = :toyama_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':toyama_infected', $toyama_infected, PDO::PARAM_INT); 
$stmt->bindValue(':toyama_injured', $toyama_injured, PDO::PARAM_INT);
$stmt->bindValue(':toyama_bed', $toyama_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('toyama.php');
}
