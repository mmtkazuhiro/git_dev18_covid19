<?php

require_once('funcs.php');

//1. POSTデータ取得
    $oita_infected = $_POST['oita_infected'];
    $oita_injured = $_POST['oita_injured'];
    $oita_bed = $_POST['oita_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        oita_infected = :oita_infected,
                        oita_injured = :oita_injured,
                        oita_bed = :oita_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':oita_infected', $oita_infected, PDO::PARAM_INT); 
$stmt->bindValue(':oita_injured', $oita_injured, PDO::PARAM_INT);
$stmt->bindValue(':oita_bed', $oita_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('oita.php');
}
