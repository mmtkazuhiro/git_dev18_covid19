<?php

require_once('funcs.php');

//1. POSTデータ取得
    $kyoto_infected = $_POST['kyoto_infected'];
    $kyoto_injured = $_POST['kyoto_injured'];
    $kyoto_bed = $_POST['kyoto_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        kyoto_infected = :kyoto_infected,
                        kyoto_injured = :kyoto_injured,
                        kyoto_bed = :kyoto_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':kyoto_infected', $kyoto_infected, PDO::PARAM_INT); 
$stmt->bindValue(':kyoto_injured', $kyoto_injured, PDO::PARAM_INT);
$stmt->bindValue(':kyoto_bed', $kyoto_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('kyoto.php');
}
