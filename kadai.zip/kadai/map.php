<?php

require_once('funcs.php');
// require_once('infected.php');

$pdo = db_conn();
$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM gs_c_table WHERE id = " . $id . ';');
$status = $stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($status == false) {
    // ここもfuncs.phpで関数化したsql_errorを使う
    sql_error($status);
}

// echo $result['hokkaido_infected'];

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>過去のコロナ感染状況</title>
<link href="css/select.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="situation">過去の日本のコロナ感染状況</div>


<div class="tabs">
<input id="infec" type="radio" name="tab_item" checked>
<label class="tab_item" for="infec">感染者数</label>

<input id="inju" type="radio" name="tab_item">
<label class="tab_item" for="inju">重傷者数</label>

<input id="be" type="radio" name="tab_item">
<label class="tab_item" for="be">病床数</label>

<div class="tab_content" id="infected_content">

<div class="time"><?= $result['indate'] ?>　時点の感染者数</div>


<div id="japan-map" class="clearfix">
	
<div id="hokkaido-touhoku" class="clearfix">
	<p class="area-title">北海道・東北</p>
	<div class="area">
		<a href="hokkaido.php">
        	<div id="hokkaido">
				<p>北海道 <br> <?= $result['hokkaido_infected'] ?></p>
          	</div>
		</a>
		<a href="aomori.php">
			<div id="aomori">
				<p>青森<br><?= $result['aomori_infected'] ?></p>
			</div>
		</a>
        <a href="iwate.php">
			<div id="iwate">
				<p>岩手<br><?= $result['iwate_infected'] ?></p>
			</div>
		</a>
        <a href="miyagi.php">
			<div id="miyagi">
				<p>宮城<br><?= $result['miyagi_infected'] ?></p>
			</div>
		</a>
		<a href="akita.php">
			<div id="akita">
				<p>秋田<br><?= $result['akita_infected'] ?></p>
			</div>
		</a>
		<a href="yamagata.php">
			<div id="yamagata">
				<p>山形<br><?= $result['yamagata_infected'] ?></p>
			</div>
		</a>

		<a href="fukushima.php">
			<div id="fukushima">
				<p>福島<br><?= $result['fukushima_infected'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="kantou">
	<p class="area-title">関東</p>
	<div class="area">
        <a href="ibaraki.php">
			<div id="ibaraki">
				<p>茨城<br><?= $result['ibaraki_infected'] ?></p>
			</div>
		</a>
        <a href="tochigi.php">
			<div id="tochigi">
				<p>栃木<br><?= $result['tochigi_infected'] ?></p>
			</div>
		</a>
		<a href="gunma.php">
			<div id="gunma">
				<p>群馬<br><?= $result['gunma_infected'] ?></p>
			</div>
		</a>
		<a href="saitama.php">
			<div id="saitama">
				<p>埼玉<br><?= $result['saitama_infected'] ?></p>
			</div>
		</a>
		<a href="chiba.php">
			<div id="chiba">
				<p>千葉<br><?= $result['chiba_infected'] ?></p>
			</div>
		</a>
		<a href="tokyo.php">
			<div id="tokyo">
				<p>東京<br><?= $result['tokyo_infected'] ?></p>
			</div>
		</a>
		<a href="kanagawa.php">
			<div id="kanagawa">
				<p>神奈川<br><?= $result['kanagawa_infected'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="tyubu" class="clearfix">
	<p class="area-title">中部</p>
	<div class="area">
		<a href="niigata.php">
			<div id="niigata">
				<p>新潟<br><?= $result['niigata_infected'] ?></p>
			</div>
		</a>
		<a href="toyama.php">
			<div id="toyama">
				<p>富山<br><?= $result['toyama_infected'] ?></p>
			</div>
		</a>
		<a href="ishikawa.php">
			<div id="ishikawa">
				<p>石川<br><?= $result['ishikawa_infected'] ?></p>
			</div>
		</a>
		<a href="fukui.php">
			<div id="fukui">
				<p>福井<br><?= $result['fukui_infected'] ?></p>
			</div>
		</a>
        <a href="yamanashi.php">
			<div id="yamanashi">
				<p>山梨<br><?= $result['yamanashi_infected'] ?></p>
			</div>
		</a>
		<a href="nagano.php">
			<div id="nagano">
				<p>長野<br><?= $result['nagano_infected'] ?></p>
			</div>
		</a>
		<a href="gifu.php">
			<div id="gifu">
				<p>岐阜<br><?= $result['gifu_infected'] ?></p>
			</div>
		</a>
        <a href="shizuoka.php">
			<div id="shizuoka">
				<p>静岡<br><?= $result['shizuoka_infected'] ?></p>
			</div>
		</a>
		<a href="aichi.php">
			<div id="aichi">
				<p>愛知<br><?= $result['aichi_infected'] ?></p>
			</div>
		</a>

	</div>
</div>

<div id="kinki" class="clearfix">
	<p class="area-title">近畿</p>
	<div class="area">
        <a href="mie.php">
			<div id="mie">
				<p>三重<br><?= $result['mie_infected'] ?></p>
			</div>
		</a>
        <a href="shiga.php">
			<div id="shiga">
				<p>滋賀<br><?= $result['shiga_infected'] ?></p>
			</div>
		</a>
		<a href="kyoto.php">
			<div id="kyoto">
				<p>京都<br><?= $result['kyoto_infected'] ?></p>
			</div>
		</a>

		<a href="osaka.php">
			<div id="osaka">
				<p>大阪<br><?= $result['osaka_infected'] ?></p>
			</div>
		</a>
        <a href="hyogo.php">
			<div id="hyogo">
				<p>兵庫<br><?= $result['hyogo_infected'] ?></p>
			</div>
		</a>
		<a href="nara.php">
			<div id="nara">
				<p>奈良<br><?= $result['nara_infected'] ?></p>
			</div>
		</a>
		<a href="wakayama.php">
			<div id="wakayama">
				<p>和歌山<br><?= $result['wakayama_infected'] ?></p>
			</div>
		</a>

	</div>
</div>

<div id="tyugoku" class="clearfix">
	<p class="area-title">中国</p>
	<div class="area">
		<a href="tottori.php">
			<div id="tottori">
				<p>鳥取<br><?= $result['tottori_infected'] ?></p>
			</div>
		</a>
        <a href="shimane.php">
			<div id="shimane">
				<p>島根<br><?= $result['shimane_infected'] ?></p>
			</div>
		</a>
		<a href="okayama.php">
			<div id="okayama">
				<p>岡山<br><?= $result['okayama_infected'] ?></p>
			</div>
		</a>
		<a href="hiroshima.php">
			<div id="hiroshima">
				<p>広島<br><?= $result['hiroshima_infected'] ?></p>
			</div>
		</a>
		<a href="yamaguchi.php">
			<div id="yamaguchi">
				<p>山口<br><?= $result['yamaguchi_infected'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="shikoku" class="clearfix">
	<p class="area-title">四国</p>
	<div class="area">
        <a href="tokushima.php">
			<div id="tokushima">
				<p>徳島<br><?= $result['tokushima_infected'] ?></p>
			</div>
		</a>
		<a href="kagawa.php">
			<div id="kagawa">
				<p>香川<br><?= $result['kagawa_infected'] ?></p>
			</div>
		</a>
		<a href="ehime.php">
			<div id="ehime">
				<p>愛媛<br><?= $result['ehime_infected'] ?></p>
			</div>
		</a>
		<a href="kochi.php">
			<div id="kochi">
				<p>高知<br><?= $result['kochi_infected'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="kyusyu" class="clearfix">
	<p class="area-title">九州・沖縄</p>
	<div class="area">
		<a href="fukuoka.php">
			<div id="fukuoka">
				<p>福岡<br><?= $result['fukuoka_infected'] ?></p>
			</div>
		</a>
		<a href="saga.php">
			<div id="saga">
				<p>佐賀<br><?= $result['saga_infected'] ?></p>
			</div>
		</a>
		<a href="nagasaki.php">
			<div id="nagasaki">
				<p>長崎<br><?= $result['nagasaki_infected'] ?></p>
			</div>
		</a>
        <a href="kumamoto.php">
			<div id="kumamoto">
				<p>熊本<br><?= $result['kumamoto_infected'] ?></p>
			</div>
		</a>
		<a href="oita.php">
			<div id="oita">
				<p>大分<br><?= $result['oita_infected'] ?></p>
			</div>
		</a>
		<a href="miyazaki.php">
			<div id="miyazaki">
				<p>宮崎<br><?= $result['miyazaki_infected'] ?></p>
			</div>
		</a>
		<a href="kagoshima.php">
			<div id="kagoshima">
				<p>鹿児島<br><?= $result['kagoshima_infected'] ?></p>
			</div>
		</a>
		<a href="okinawa.php">
			<div id="okinawa">
				<p>沖縄<br><?= $result['okinawa_infected'] ?></p>
			</div>
		</a>
	</div>
</div>

</div> <!-- japan-map -->
</div>

<div class="tab_content" id="injured_content">
<div class="time"><?= $result['indate'] ?>　時点の重傷者数</div>

<div id="japan-map" class="clearfix">
	
<div id="hokkaido-touhoku" class="clearfix">
	<p class="area-title">北海道・東北</p>
	<div class="area">
		<a href="hokkaido.php">
        	<div id="hokkaido">
				<p>北海道<br><?= $result['hokkaido_injured'] ?></p>
          	</div>
		</a>
		<a href="aomori.php">
			<div id="aomori">
				<p>青森<br><?= $result['aomori_injured'] ?></p>
			</div>
		</a>
        <a href="iwate.php">
			<div id="iwate">
				<p>岩手<br><?= $result['iwate_injured'] ?></p>
			</div>
		</a>
        <a href="miyagi.php">
			<div id="miyagi">
				<p>宮城<br><?= $result['miyagi_injured'] ?></p>
			</div>
		</a>
		<a href="akita.php">
			<div id="akita">
				<p>秋田<br><?= $result['akita_injured'] ?></p>
			</div>
		</a>
		<a href="yamagata.php">
			<div id="yamagata">
				<p>山形<br><?= $result['yamagata_injured'] ?></p>
			</div>
		</a>

		<a href="fukushima.php">
			<div id="fukushima">
				<p>福島<br><?= $result['fukushima_injured'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="kantou">
	<p class="area-title">関東</p>
	<div class="area">
        <a href="ibaraki.php">
			<div id="ibaraki">
				<p>茨城<br><?= $result['ibaraki_injured'] ?></p>
			</div>
		</a>
        <a href="tochigi.php">
			<div id="tochigi">
				<p>栃木<br><?= $result['tochigi_injured'] ?></p>
			</div>
		</a>
		<a href="gunma.php">
			<div id="gunma">
				<p>群馬<br><?= $result['gunma_injured'] ?></p>
			</div>
		</a>
		<a href="saitama.php">
			<div id="saitama">
				<p>埼玉<br><?= $result['saitama_injured'] ?></p>
			</div>
		</a>
		<a href="chiba.php">
			<div id="chiba">
				<p>千葉<br><?= $result['chiba_injured'] ?></p>
			</div>
		</a>
		<a href="tokyo.php">
			<div id="tokyo">
				<p>東京<br><?= $result['tokyo_injured'] ?></p>
			</div>
		</a>
		<a href="kanagawa.php">
			<div id="kanagawa">
				<p>神奈川<br><?= $result['kanagawa_injured'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="tyubu" class="clearfix">
	<p class="area-title">中部</p>
	<div class="area">
		<a href="niigata.php">
			<div id="niigata">
				<p>新潟<br><?= $result['niigata_injured'] ?></p>
			</div>
		</a>
		<a href="toyama.php">
			<div id="toyama">
				<p>富山<br><?= $result['toyama_injured'] ?></p>
			</div>
		</a>
		<a href="ishikawa.php">
			<div id="ishikawa">
				<p>石川<br><?= $result['ishikawa_injured'] ?></p>
			</div>
		</a>
		<a href="fukui.php">
			<div id="fukui">
				<p>福井<br><?= $result['fukui_injured'] ?></p>
			</div>
		</a>
        <a href="yamanashi.php">
			<div id="yamanashi">
				<p>山梨<br><?= $result['yamanashi_injured'] ?></p>
			</div>
		</a>
		<a href="nagano.php">
			<div id="nagano">
				<p>長野<br><?= $result['nagano_injured'] ?></p>
			</div>
		</a>
		<a href="gifu.php">
			<div id="gifu">
				<p>岐阜<br><?= $result['gifu_injured'] ?></p>
			</div>
		</a>
        <a href="shizuoka.php">
			<div id="shizuoka">
				<p>静岡<br><?= $result['shizuoka_injured'] ?></p>
			</div>
		</a>
		<a href="aichi.php">
			<div id="aichi">
				<p>愛知<br><?= $result['aichi_injured'] ?></p>
			</div>
		</a>

	</div>
</div>

<div id="kinki" class="clearfix">
	<p class="area-title">近畿</p>
	<div class="area">
        <a href="mie.php">
			<div id="mie">
				<p>三重<br><?= $result['mie_injured'] ?></p>
			</div>
		</a>
        <a href="shiga.php">
			<div id="shiga">
				<p>滋賀<br><?= $result['shiga_injured'] ?></p>
			</div>
		</a>
		<a href="kyoto.php">
			<div id="kyoto">
				<p>京都<br><?= $result['kyoto_injured'] ?></p>
			</div>
		</a>

		<a href="osaka.php">
			<div id="osaka">
				<p>大阪<br><?= $result['osaka_injured'] ?></p>
			</div>
		</a>
        <a href="hyogo.php">
			<div id="hyogo">
				<p>兵庫<br><?= $result['hyogo_injured'] ?></p>
			</div>
		</a>
		<a href="nara.php">
			<div id="nara">
				<p>奈良<br><?= $result['nara_injured'] ?></p>
			</div>
		</a>
		<a href="wakayama.php">
			<div id="wakayama">
				<p>和歌山<br><?= $result['wakayama_injured'] ?></p>
			</div>
		</a>

	</div>
</div>

<div id="tyugoku" class="clearfix">
	<p class="area-title">中国</p>
	<div class="area">
		<a href="tottori.php">
			<div id="tottori">
				<p>鳥取<br><?= $result['tottori_injured'] ?></p>
			</div>
		</a>
        <a href="shimane.php">
			<div id="shimane">
				<p>島根<br><?= $result['shimane_injured'] ?></p>
			</div>
		</a>
		<a href="okayama.php">
			<div id="okayama">
				<p>岡山<br><?= $result['okayama_injured'] ?></p>
			</div>
		</a>
		<a href="hiroshima.php">
			<div id="hiroshima">
				<p>広島<br><?= $result['hiroshima_injured'] ?></p>
			</div>
		</a>
		<a href="yamaguchi.php">
			<div id="yamaguchi">
				<p>山口<br><?= $result['yamaguchi_injured'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="shikoku" class="clearfix">
	<p class="area-title">四国</p>
	<div class="area">
        <a href="tokushima.php">
			<div id="tokushima">
				<p>徳島<br><?= $result['tokushima_injured'] ?></p>
			</div>
		</a>
		<a href="kagawa.php">
			<div id="kagawa">
				<p>香川<br><?= $result['kagawa_injured'] ?></p>
			</div>
		</a>
		<a href="ehime.php">
			<div id="ehime">
				<p>愛媛<br><?= $result['ehime_injured'] ?></p>
			</div>
		</a>
		<a href="kochi.php">
			<div id="kochi">
				<p>高知<br><?= $result['kochi_injured'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="kyusyu" class="clearfix">
	<p class="area-title">九州・沖縄</p>
	<div class="area">
		<a href="fukuoka.php">
			<div id="fukuoka">
				<p>福岡<br><?= $result['fukuoka_injured'] ?></p>
			</div>
		</a>
		<a href="saga.php">
			<div id="saga">
				<p>佐賀<br><?= $result['saga_injured'] ?></p>
			</div>
		</a>
		<a href="nagasaki.php">
			<div id="nagasaki">
				<p>長崎<br><?= $result['nagasaki_injured'] ?></p>
			</div>
		</a>
        <a href="kumamoto.php">
			<div id="kumamoto">
				<p>熊本<br><?= $result['kumamoto_injured'] ?></p>
			</div>
		</a>
		<a href="oita.php">
			<div id="oita">
				<p>大分<br><?= $result['oita_injured'] ?></p>
			</div>
		</a>
		<a href="miyazaki.php">
			<div id="miyazaki">
				<p>宮崎<br><?= $result['miyazaki_injured'] ?></p>
			</div>
		</a>
		<a href="kagoshima.php">
			<div id="kagoshima">
				<p>鹿児島<br><?= $result['kagoshima_injured'] ?></p>
			</div>
		</a>
		<a href="okinawa.php">
			<div id="okinawa">
				<p>沖縄<br><?= $result['okinawa_injured'] ?></p>
			</div>
		</a>
	</div>
</div>

</div> <!-- japan-map -->
</div>

<div class="tab_content" id="bed_content">
<div class="time"><?= $result['indate'] ?>　時点の病床数</div>

<div id="japan-map" class="clearfix">
	
<div id="hokkaido-touhoku" class="clearfix">
	<p class="area-title">北海道・東北</p>
	<div class="area">
		<a href="hokkaido.php">
        	<div id="hokkaido">
				<p>北海道<br><?= $result['hokkaido_bed'] ?></p>
          	</div>
		</a>
		<a href="aomori.php">
			<div id="aomori">
				<p>青森<br><?= $result['aomori_bed'] ?></p>
			</div>
		</a>
        <a href="iwate.php">
			<div id="iwate">
				<p>岩手<br><?= $result['iwate_bed'] ?></p>
			</div>
		</a>
        <a href="miyagi.php">
			<div id="miyagi">
				<p>宮城<br><?= $result['miyagi_bed'] ?></p>
			</div>
		</a>
		<a href="akita.php">
			<div id="akita">
				<p>秋田<br><?= $result['akita_bed'] ?></p>
			</div>
		</a>
		<a href="yamagata.php">
			<div id="yamagata">
				<p>山形<br><?= $result['yamagata_bed'] ?></p>
			</div>
		</a>

		<a href="fukushima.php">
			<div id="fukushima">
				<p>福島<br><?= $result['fukushima_bed'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="kantou">
	<p class="area-title">関東</p>
	<div class="area">
        <a href="ibaraki.php">
			<div id="ibaraki">
				<p>茨城<br><?= $result['ibaraki_bed'] ?></p>
			</div>
		</a>
        <a href="tochigi.php">
			<div id="tochigi">
				<p>栃木<br><?= $result['tochigi_bed'] ?></p>
			</div>
		</a>
		<a href="gunma.php">
			<div id="gunma">
				<p>群馬<br><?= $result['gunma_bed'] ?></p>
			</div>
		</a>
		<a href="saitama.php">
			<div id="saitama">
				<p>埼玉<br><?= $result['saitama_bed'] ?></p>
			</div>
		</a>
		<a href="chiba.php">
			<div id="chiba">
				<p>千葉<br><?= $result['chiba_bed'] ?></p>
			</div>
		</a>
		<a href="tokyo.php">
			<div id="tokyo">
				<p>東京<br><?= $result['tokyo_bed'] ?></p>
			</div>
		</a>
		<a href="kanagawa.php">
			<div id="kanagawa">
				<p>神奈川<br><?= $result['kanagawa_bed'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="tyubu" class="clearfix">
	<p class="area-title">中部</p>
	<div class="area">
		<a href="niigata.php">
			<div id="niigata">
				<p>新潟<br><?= $result['niigata_bed'] ?></p>
			</div>
		</a>
		<a href="toyama.php">
			<div id="toyama">
				<p>富山<br><?= $result['toyama_bed'] ?></p>
			</div>
		</a>
		<a href="ishikawa.php">
			<div id="ishikawa">
				<p>石川<br><?= $result['ishikawa_bed'] ?></p>
			</div>
		</a>
		<a href="fukui.php">
			<div id="fukui">
				<p>福井<br><?= $result['fukui_bed'] ?></p>
			</div>
		</a>
        <a href="yamanashi.php">
			<div id="yamanashi">
				<p>山梨<br><?= $result['yamanashi_bed'] ?></p>
			</div>
		</a>
		<a href="nagano.php">
			<div id="nagano">
				<p>長野<br><?= $result['nagano_bed'] ?></p>
			</div>
		</a>
		<a href="gifu.php">
			<div id="gifu">
				<p>岐阜<br><?= $result['gifu_bed'] ?></p>
			</div>
		</a>
        <a href="shizuoka.php">
			<div id="shizuoka">
				<p>静岡<br><?= $result['shizuoka_bed'] ?></p>
			</div>
		</a>
		<a href="aichi.php">
			<div id="aichi">
				<p>愛知<br><?= $result['aichi_bed'] ?></p>
			</div>
		</a>

	</div>
</div>

<div id="kinki" class="clearfix">
	<p class="area-title">近畿</p>
	<div class="area">
        <a href="mie.php">
			<div id="mie">
				<p>三重<br><?= $result['mie_bed'] ?></p>
			</div>
		</a>
        <a href="shiga.php">
			<div id="shiga">
				<p>滋賀<br><?= $result['shiga_bed'] ?></p>
			</div>
		</a>
		<a href="kyoto.php">
			<div id="kyoto">
				<p>京都<br><?= $result['kyoto_bed'] ?></p>
			</div>
		</a>

		<a href="osaka.php">
			<div id="osaka">
				<p>大阪<br><?= $result['osaka_bed'] ?></p>
			</div>
		</a>
        <a href="hyogo.php">
			<div id="hyogo">
				<p>兵庫<br><?= $result['hyogo_bed'] ?></p>
			</div>
		</a>
		<a href="nara.php">
			<div id="nara">
				<p>奈良<br><?= $result['nara_bed'] ?></p>
			</div>
		</a>
		<a href="wakayama.php">
			<div id="wakayama">
				<p>和歌山<br><?= $result['wakayama_bed'] ?></p>
			</div>
		</a>

	</div>
</div>

<div id="tyugoku" class="clearfix">
	<p class="area-title">中国</p>
	<div class="area">
		<a href="tottori.php">
			<div id="tottori">
				<p>鳥取<br><?= $result['tottori_bed'] ?></p>
			</div>
		</a>
        <a href="shimane.php">
			<div id="shimane">
				<p>島根<br><?= $result['shimane_bed'] ?></p>
			</div>
		</a>
		<a href="okayama.php">
			<div id="okayama">
				<p>岡山<br><?= $result['okayama_bed'] ?></p>
			</div>
		</a>
		<a href="hiroshima.php">
			<div id="hiroshima">
				<p>広島<br><?= $result['hiroshima_bed'] ?></p>
			</div>
		</a>
		<a href="yamaguchi.php">
			<div id="yamaguchi">
				<p>山口<br><?= $result['yamaguchi_bed'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="shikoku" class="clearfix">
	<p class="area-title">四国</p>
	<div class="area">
        <a href="tokushima.php">
			<div id="tokushima">
				<p>徳島<br><?= $result['tokushima_bed'] ?></p>
			</div>
		</a>
		<a href="kagawa.php">
			<div id="kagawa">
				<p>香川<br><?= $result['kagawa_bed'] ?></p>
			</div>
		</a>
		<a href="ehime.php">
			<div id="ehime">
				<p>愛媛<br><?= $result['ehime_bed'] ?></p>
			</div>
		</a>
		<a href="kochi.php">
			<div id="kochi">
				<p>高知<br><?= $result['kochi_bed'] ?></p>
			</div>
		</a>
	</div>
</div>

<div id="kyusyu" class="clearfix">
	<p class="area-title">九州・沖縄</p>
	<div class="area">
		<a href="fukuoka.php">
			<div id="fukuoka">
				<p>福岡<br><?= $result['fukuoka_bed'] ?></p>
			</div>
		</a>
		<a href="saga.php">
			<div id="saga">
				<p>佐賀<br><?= $result['saga_bed'] ?></p>
			</div>
		</a>
		<a href="nagasaki.php">
			<div id="nagasaki">
				<p>長崎<br><?= $result['nagasaki_bed'] ?></p>
			</div>
		</a>
        <a href="kumamoto.php">
			<div id="kumamoto">
				<p>熊本<br><?= $result['kumamoto_bed'] ?></p>
			</div>
		</a>
		<a href="oita.php">
			<div id="oita">
				<p>大分<br><?= $result['oita_bed'] ?></p>
			</div>
		</a>
		<a href="miyazaki.php">
			<div id="miyazaki">
				<p>宮崎<br><?= $result['miyazaki_bed'] ?></p>
			</div>
		</a>
		<a href="kagoshima.php">
			<div id="kagoshima">
				<p>鹿児島<br><?= $result['kagoshima_bed'] ?></p>
			</div>
		</a>
		<a href="okinawa.php">
			<div id="okinawa">
				<p>沖縄<br><?= $result['okinawa_bed'] ?></p>
			</div>
		</a>
	</div>
</div>

</div> <!-- japan-map -->

</div>

</div>

<div class="outoutcovid">
	<div class="outcovid">
		<a href="covid.php" class="return_covid">←登録へ戻る</a>
	</div>
</div>

</body>
</html>
