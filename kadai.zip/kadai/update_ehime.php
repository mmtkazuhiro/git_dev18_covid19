<?php

require_once('funcs.php');

//1. POSTデータ取得
    $ehime_infected = $_POST['ehime_infected'];
    $ehime_injured = $_POST['ehime_injured'];
    $ehime_bed = $_POST['ehime_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        ehime_infected = :ehime_infected,
                        ehime_injured = :ehime_injured,
                        ehime_bed = :ehime_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':ehime_infected', $ehime_infected, PDO::PARAM_INT); 
$stmt->bindValue(':ehime_injured', $ehime_injured, PDO::PARAM_INT);
$stmt->bindValue(':ehime_bed', $ehime_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('ehime.php');
}
