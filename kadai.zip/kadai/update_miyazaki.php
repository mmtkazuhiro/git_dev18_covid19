<?php

require_once('funcs.php');

//1. POSTデータ取得
    $miyazaki_infected = $_POST['miyazaki_infected'];
    $miyazaki_injured = $_POST['miyazaki_injured'];
    $miyazaki_bed = $_POST['miyazaki_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        miyazaki_infected = :miyazaki_infected,
                        miyazaki_injured = :miyazaki_injured,
                        miyazaki_bed = :miyazaki_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':miyazaki_infected', $miyazaki_infected, PDO::PARAM_INT); 
$stmt->bindValue(':miyazaki_injured', $miyazaki_injured, PDO::PARAM_INT);
$stmt->bindValue(':miyazaki_bed', $miyazaki_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('miyazaki.php');
}
