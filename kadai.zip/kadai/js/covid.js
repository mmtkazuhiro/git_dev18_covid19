// $(function(){
//     alert('逼迫率80%を超えると音声が出ますので音量にご注意してください');
// })

// ポップアップを1回しか表示させないようにする
// ここから
$(function(){
    $(".outalert").show();
    $.cookie('btnFlg') == 'on'?$(".outalert").hide():$(".outalert").show();
    $(".alert button").click(function(){
        $(".outalert").fadeOut();
        $.cookie('btnFlg', 'on', { expires: 30,path: '/' }); //cookieの保存
    });
});
// ここまで

// エンターで送信されないようにする
// ここから
$(function(){
    $("input"). keydown(function(e) {
        if ((e.which && e.which === 13) || (e.keyCode && e.keyCode === 13)) {
            return false;
        } else {
            return true;
        }
    });
});
// ここまで

hokkaido_bed.addEventListener("change",function(){

    let hokkaido_injured = document.getElementById("hokkaido_injured").value;
    let hokkaido_bed = document.getElementById("hokkaido_bed").value;
    let hokkaido_tight = document.getElementById("hokkaido_tight");

    let hokkaido_result = hokkaido_injured / hokkaido_bed * 100;
    let hokkaido_result_output = (Math.round(hokkaido_result * 10)) / 10;

    console.log(hokkaido_injured);
    console.log(hokkaido_bed);
    console.log(hokkaido_result);
    console.log(hokkaido_result_output);

    hokkaido_tight.innerHTML = hokkaido_result_output + '%';

    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");


    if (hokkaido_result_output >= 80 && hokkaido_result_output<95){
        hokkaido_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (hokkaido_result_output >= 95){
        hokkaido_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

aomori_bed.addEventListener("change",function(){

    let aomori_injured = document.getElementById("aomori_injured").value;
    let aomori_bed = document.getElementById("aomori_bed").value;
    let aomori_tight = document.getElementById("aomori_tight");

    let aomori_result = aomori_injured / aomori_bed * 100;
    let aomori_result_output = (Math.round(aomori_result * 10)) / 10;

    aomori_tight.innerHTML = aomori_result_output + '%';

    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");


    if (aomori_result_output >= 80){
        aomori_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (aomori_result_output >= 95){
        aomori_tight.style.color = '#ff0000';
        bgm2.play();
    }

});

iwate_bed.addEventListener("change",function(){

    let iwate_injured = document.getElementById("iwate_injured").value;
    let iwate_bed = document.getElementById("iwate_bed").value;
    let iwate_tight = document.getElementById("iwate_tight");

    let iwate_result = iwate_injured / iwate_bed * 100;
    let iwate_result_output = (Math.round(iwate_result * 10)) / 10;

    iwate_tight.innerHTML = iwate_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (iwate_result_output >= 80){
        iwate_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (iwate_result_output >= 95){
        iwate_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

miyagi_bed.addEventListener("change",function(){

    let miyagi_injured = document.getElementById("miyagi_injured").value;
    let miyagi_bed = document.getElementById("miyagi_bed").value;
    let miyagi_tight = document.getElementById("miyagi_tight");

    let miyagi_result = miyagi_injured / miyagi_bed * 100;
    let miyagi_result_output = (Math.round(miyagi_result * 10)) / 10;

    miyagi_tight.innerHTML = miyagi_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (miyagi_result_output >= 80){
        miyagi_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (miyagi_result_output >= 95){
        miyagi_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

akita_bed.addEventListener("change",function(){

    let akita_injured = document.getElementById("akita_injured").value;
    let akita_bed = document.getElementById("akita_bed").value;
    let akita_tight = document.getElementById("akita_tight");

    let akita_result = akita_injured / akita_bed * 100;
    let akita_result_output = (Math.round(akita_result * 10)) / 10;

    akita_tight.innerHTML = akita_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");
    
    if (akita_result_output >= 80){
        akita_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (akita_result_output >= 95){
        akita_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

yamagata_bed.addEventListener("change",function(){

    let yamagata_injured = document.getElementById("yamagata_injured").value;
    let yamagata_bed = document.getElementById("yamagata_bed").value;
    let yamagata_tight = document.getElementById("yamagata_tight");

    let yamagata_result = yamagata_injured / yamagata_bed * 100;
    let yamagata_result_output = (Math.round(yamagata_result * 10)) / 10;

    yamagata_tight.innerHTML = yamagata_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (yamagata_result_output >= 80){
        yamagata_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (yamagata_result_output >= 95){
        yamagata_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

fukushima_bed.addEventListener("change",function(){

    let fukushima_injured = document.getElementById("fukushima_injured").value;
    let fukushima_bed = document.getElementById("fukushima_bed").value;
    let fukushima_tight = document.getElementById("fukushima_tight");

    let fukushima_result = fukushima_injured / fukushima_bed * 100;
    let fukushima_result_output = (Math.round(fukushima_result * 10)) / 10;

    fukushima_tight.innerHTML = fukushima_result_output + '%';
        let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (fukushima_result_output >= 80){
        fukushima_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (fukushima_result_output >= 95){
        fukushima_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

ibaraki_bed.addEventListener("change",function(){

    let ibaraki_injured = document.getElementById("ibaraki_injured").value;
    let ibaraki_bed = document.getElementById("ibaraki_bed").value;
    let ibaraki_tight = document.getElementById("ibaraki_tight");

    let ibaraki_result = ibaraki_injured / ibaraki_bed * 100;
    let ibaraki_result_output = (Math.round(ibaraki_result * 10)) / 10;

    ibaraki_tight.innerHTML = ibaraki_result_output + '%';
    let bgm = document.querySelector("#sound1");
let bgm2 = document.querySelector("#sound2");

    if (ibaraki_result_output >= 80){
        ibaraki_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (ibaraki_result_output >= 95){
        ibaraki_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

tochigi_bed.addEventListener("change",function(){

    let tochigi_injured = document.getElementById("tochigi_injured").value;
    let tochigi_bed = document.getElementById("tochigi_bed").value;
    let tochigi_tight = document.getElementById("tochigi_tight");

    let tochigi_result = tochigi_injured / tochigi_bed * 100;
    let tochigi_result_output = (Math.round(tochigi_result * 10)) / 10;

    tochigi_tight.innerHTML = tochigi_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (tochigi_result_output >= 80){
        tochigi_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (tochigi_result_output >= 95){
        tochigi_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

gunma_bed.addEventListener("change",function(){

    let gunma_injured = document.getElementById("gunma_injured").value;
    let gunma_bed = document.getElementById("gunma_bed").value;
    let gunma_tight = document.getElementById("gunma_tight");

    let gunma_result = gunma_injured / gunma_bed * 100;
    let gunma_result_output = (Math.round(gunma_result * 10)) / 10;

    gunma_tight.innerHTML = gunma_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (gunma_result_output >= 80){
        gunma_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (gunma_result_output >= 95){
        gunma_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

saitama_bed.addEventListener("change",function(){

    let saitama_injured = document.getElementById("saitama_injured").value;
    let saitama_bed = document.getElementById("saitama_bed").value;
    let saitama_tight = document.getElementById("saitama_tight");

    let saitama_result = saitama_injured / saitama_bed * 100;
    let saitama_result_output = (Math.round(saitama_result * 10)) / 10;

    saitama_tight.innerHTML = saitama_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (saitama_result_output >= 80){
        saitama_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (saitama_result_output >= 95){
        saitama_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

chiba_bed.addEventListener("change",function(){

    let chiba_injured = document.getElementById("chiba_injured").value;
    let chiba_bed = document.getElementById("chiba_bed").value;
    let chiba_tight = document.getElementById("chiba_tight");

    let chiba_result = chiba_injured / chiba_bed * 100;
    let chiba_result_output = (Math.round(chiba_result * 10)) / 10;

    chiba_tight.innerHTML = chiba_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (chiba_result_output >= 80){
        chiba_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (chiba_result_output >= 95){
        chiba_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

tokyo_bed.addEventListener("change",function(){

    let tokyo_injured = document.getElementById("tokyo_injured").value;
    let tokyo_bed = document.getElementById("tokyo_bed").value;
    let tokyo_tight = document.getElementById("tokyo_tight");

    let tokyo_result = tokyo_injured / tokyo_bed * 100;
    let tokyo_result_output = (Math.round(tokyo_result * 10)) / 10;

    tokyo_tight.innerHTML = tokyo_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (tokyo_result_output >= 80){
        tokyo_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (tokyo_result_output >= 95){
        tokyo_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

kanagawa_bed.addEventListener("change",function(){

    let kanagawa_injured = document.getElementById("kanagawa_injured").value;
    let kanagawa_bed = document.getElementById("kanagawa_bed").value;
    let kanagawa_tight = document.getElementById("kanagawa_tight");

    let kanagawa_result = kanagawa_injured / kanagawa_bed * 100;
    let kanagawa_result_output = (Math.round(kanagawa_result * 10)) / 10;

    kanagawa_tight.innerHTML = kanagawa_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (kanagawa_result_output >= 80){
        kanagawa_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (kanagawa_result_output >= 95){
        kanagawa_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

niigata_bed.addEventListener("change",function(){

    let niigata_injured = document.getElementById("niigata_injured").value;
    let niigata_bed = document.getElementById("niigata_bed").value;
    let niigata_tight = document.getElementById("niigata_tight");

    let niigata_result = niigata_injured / niigata_bed * 100;
    let niigata_result_output = (Math.round(niigata_result * 10)) / 10;

    niigata_tight.innerHTML = niigata_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (niigata_result_output >= 80){
        niigata_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (niigata_result_output >= 95){
        niigata_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

toyama_bed.addEventListener("change",function(){

    let toyama_injured = document.getElementById("toyama_injured").value;
    let toyama_bed = document.getElementById("toyama_bed").value;
    let toyama_tight = document.getElementById("toyama_tight");

    let toyama_result = toyama_injured / toyama_bed * 100;
    let toyama_result_output = (Math.round(toyama_result * 10)) / 10;

    toyama_tight.innerHTML = toyama_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (toyama_result_output >= 80){
        toyama_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (toyama_result_output >= 95){
        toyama_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

ishikawa_bed.addEventListener("change",function(){

    let ishikawa_injured = document.getElementById("ishikawa_injured").value;
    let ishikawa_bed = document.getElementById("ishikawa_bed").value;
    let ishikawa_tight = document.getElementById("ishikawa_tight");

    let ishikawa_result = ishikawa_injured / ishikawa_bed * 100;
    let ishikawa_result_output = (Math.round(ishikawa_result * 10)) / 10;

    ishikawa_tight.innerHTML = ishikawa_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (ishikawa_result_output >= 80){
        ishikawa_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (ishikawa_result_output >= 95){
        ishikawa_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

fukui_bed.addEventListener("change",function(){

    let fukui_injured = document.getElementById("fukui_injured").value;
    let fukui_bed = document.getElementById("fukui_bed").value;
    let fukui_tight = document.getElementById("fukui_tight");

    let fukui_result = fukui_injured / fukui_bed * 100;
    let fukui_result_output = (Math.round(fukui_result * 10)) / 10;

    fukui_tight.innerHTML = fukui_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (fukui_result_output >= 80){
        fukui_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (fukui_result_output >= 95){
        fukui_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

yamanashi_bed.addEventListener("change",function(){

    let yamanashi_injured = document.getElementById("yamanashi_injured").value;
    let yamanashi_bed = document.getElementById("yamanashi_bed").value;
    let yamanashi_tight = document.getElementById("yamanashi_tight");

    let yamanashi_result = yamanashi_injured / yamanashi_bed * 100;
    let yamanashi_result_output = (Math.round(yamanashi_result * 10)) / 10;

    yamanashi_tight.innerHTML = yamanashi_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (yamanashi_result_output >= 80){
        yamanashi_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (yamanashi_result_output >= 95){
        yamanashi_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

nagano_bed.addEventListener("change",function(){

    let nagano_injured = document.getElementById("nagano_injured").value;
    let nagano_bed = document.getElementById("nagano_bed").value;
    let nagano_tight = document.getElementById("nagano_tight");

    let nagano_result = nagano_injured / nagano_bed * 100;
    let nagano_result_output = (Math.round(nagano_result * 10)) / 10;

    nagano_tight.innerHTML = nagano_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (nagano_result_output >= 80){
        nagano_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (nagano_result_output >= 95){
        nagano_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

gifu_bed.addEventListener("change",function(){

    let gifu_injured = document.getElementById("gifu_injured").value;
    let gifu_bed = document.getElementById("gifu_bed").value;
    let gifu_tight = document.getElementById("gifu_tight");

    let gifu_result = gifu_injured / gifu_bed * 100;
    let gifu_result_output = (Math.round(gifu_result * 10)) / 10;

    gifu_tight.innerHTML = gifu_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (gifu_result_output >= 80){
        gifu_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (gifu_result_output >= 95){
        gifu_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

shizuoka_bed.addEventListener("change",function(){

    let shizuoka_injured = document.getElementById("shizuoka_injured").value;
    let shizuoka_bed = document.getElementById("shizuoka_bed").value;
    let shizuoka_tight = document.getElementById("shizuoka_tight");

    let shizuoka_result = shizuoka_injured / shizuoka_bed * 100;
    let shizuoka_result_output = (Math.round(shizuoka_result * 10)) / 10;

    shizuoka_tight.innerHTML = shizuoka_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (shizuoka_result_output >= 80){
        shizuoka_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (shizuoka_result_output >= 95){
        shizuoka_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

aichi_bed.addEventListener("change",function(){

    let aichi_injured = document.getElementById("aichi_injured").value;
    let aichi_bed = document.getElementById("aichi_bed").value;
    let aichi_tight = document.getElementById("aichi_tight");

    let aichi_result = aichi_injured / aichi_bed * 100;
    let aichi_result_output = (Math.round(aichi_result * 10)) / 10;

    aichi_tight.innerHTML = aichi_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (aichi_result_output >= 80){
        aichi_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (aichi_result_output >= 95){
        aichi_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

mie_bed.addEventListener("change",function(){

    let mie_injured = document.getElementById("mie_injured").value;
    let mie_bed = document.getElementById("mie_bed").value;
    let mie_tight = document.getElementById("mie_tight");

    let mie_result = mie_injured / mie_bed * 100;
    let mie_result_output = (Math.round(mie_result * 10)) / 10;

    mie_tight.innerHTML = mie_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (mie_result_output >= 80){
        mie_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (mie_result_output >= 95){
        mie_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

shiga_bed.addEventListener("change",function(){

    let shiga_injured = document.getElementById("shiga_injured").value;
    let shiga_bed = document.getElementById("shiga_bed").value;
    let shiga_tight = document.getElementById("shiga_tight");

    let shiga_result = shiga_injured / shiga_bed * 100;
    let shiga_result_output = (Math.round(shiga_result * 10)) / 10;

    shiga_tight.innerHTML = shiga_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (shiga_result_output >= 80){
        shiga_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (shiga_result_output >= 95){
        shiga_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

kyoto_bed.addEventListener("change",function(){

    let kyoto_injured = document.getElementById("kyoto_injured").value;
    let kyoto_bed = document.getElementById("kyoto_bed").value;
    let kyoto_tight = document.getElementById("kyoto_tight");

    let kyoto_result = kyoto_injured / kyoto_bed * 100;
    let kyoto_result_output = (Math.round(kyoto_result * 10)) / 10;

    kyoto_tight.innerHTML = kyoto_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (kyoto_result_output >= 80){
        kyoto_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (kyoto_result_output >= 95){
        kyoto_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

osaka_bed.addEventListener("change",function(){

    let osaka_injured = document.getElementById("osaka_injured").value;
    let osaka_bed = document.getElementById("osaka_bed").value;
    let osaka_tight = document.getElementById("osaka_tight");

    let osaka_result = osaka_injured / osaka_bed * 100;
    let osaka_result_output = (Math.round(osaka_result * 10)) / 10;

    osaka_tight.innerHTML = osaka_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (osaka_result_output >= 80){
        osaka_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (osaka_result_output >= 95){
        osaka_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

hyogo_bed.addEventListener("change",function(){

    let hyogo_injured = document.getElementById("hyogo_injured").value;
    let hyogo_bed = document.getElementById("hyogo_bed").value;
    let hyogo_tight = document.getElementById("hyogo_tight");

    let hyogo_result = hyogo_injured / hyogo_bed * 100;
    let hyogo_result_output = (Math.round(hyogo_result * 10)) / 10;

    hyogo_tight.innerHTML = hyogo_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (hyogo_result_output >= 80){
        hyogo_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (hyogo_result_output >= 95){
        hyogo_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

nara_bed.addEventListener("change",function(){

    let nara_injured = document.getElementById("nara_injured").value;
    let nara_bed = document.getElementById("nara_bed").value;
    let nara_tight = document.getElementById("nara_tight");

    let nara_result = nara_injured / nara_bed * 100;
    let nara_result_output = (Math.round(nara_result * 10)) / 10;

    nara_tight.innerHTML = nara_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (nara_result_output >= 80){
        nara_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (nara_result_output >= 95){
        nara_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

wakayama_bed.addEventListener("change",function(){

    let wakayama_injured = document.getElementById("wakayama_injured").value;
    let wakayama_bed = document.getElementById("wakayama_bed").value;
    let wakayama_tight = document.getElementById("wakayama_tight");

    let wakayama_result = wakayama_injured / wakayama_bed * 100;
    let wakayama_result_output = (Math.round(wakayama_result * 10)) / 10;

    wakayama_tight.innerHTML = wakayama_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (wakayama_result_output >= 80){
        wakayama_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (wakayama_result_output >= 95){
        wakayama_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

tottori_bed.addEventListener("change",function(){

    let tottori_injured = document.getElementById("tottori_injured").value;
    let tottori_bed = document.getElementById("tottori_bed").value;
    let tottori_tight = document.getElementById("tottori_tight");

    let tottori_result = tottori_injured / tottori_bed * 100;
    let tottori_result_output = (Math.round(tottori_result * 10)) / 10;

    tottori_tight.innerHTML = tottori_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (tottori_result_output >= 80){
        tottori_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (tottori_result_output >= 95){
        tottori_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

shimane_bed.addEventListener("change",function(){

    let shimane_injured = document.getElementById("shimane_injured").value;
    let shimane_bed = document.getElementById("shimane_bed").value;
    let shimane_tight = document.getElementById("shimane_tight");

    let shimane_result = shimane_injured / shimane_bed * 100;
    let shimane_result_output = (Math.round(shimane_result * 10)) / 10;

    shimane_tight.innerHTML = shimane_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (shimane_result_output >= 80){
        shimane_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (shimane_result_output >= 95){
        shimane_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

okayama_bed.addEventListener("change",function(){

    let okayama_injured = document.getElementById("okayama_injured").value;
    let okayama_bed = document.getElementById("okayama_bed").value;
    let okayama_tight = document.getElementById("okayama_tight");

    let okayama_result = okayama_injured / okayama_bed * 100;
    let okayama_result_output = (Math.round(okayama_result * 10)) / 10;

    okayama_tight.innerHTML = okayama_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (okayama_result_output >= 80){
        okayama_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (okayama_result_output >= 95){
        okayama_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

hiroshima_bed.addEventListener("change",function(){

    let hiroshima_injured = document.getElementById("hiroshima_injured").value;
    let hiroshima_bed = document.getElementById("hiroshima_bed").value;
    let hiroshima_tight = document.getElementById("hiroshima_tight");

    let hiroshima_result = hiroshima_injured / hiroshima_bed * 100;
    let hiroshima_result_output = (Math.round(hiroshima_result * 10)) / 10;

    hiroshima_tight.innerHTML = hiroshima_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (hiroshima_result_output >= 80){
        hiroshima_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (hiroshima_result_output >= 95){
        hiroshima_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

yamaguchi_bed.addEventListener("change",function(){

    let yamaguchi_injured = document.getElementById("yamaguchi_injured").value;
    let yamaguchi_bed = document.getElementById("yamaguchi_bed").value;
    let yamaguchi_tight = document.getElementById("yamaguchi_tight");

    let yamaguchi_result = yamaguchi_injured / yamaguchi_bed * 100;
    let yamaguchi_result_output = (Math.round(yamaguchi_result * 10)) / 10;

    yamaguchi_tight.innerHTML = yamaguchi_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (yamaguchi_result_output >= 80){
        yamaguchi_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (yamaguchi_result_output >= 95){
        yamaguchi_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

tokushima_bed.addEventListener("change",function(){

    let tokushima_injured = document.getElementById("tokushima_injured").value;
    let tokushima_bed = document.getElementById("tokushima_bed").value;
    let tokushima_tight = document.getElementById("tokushima_tight");

    let tokushima_result = tokushima_injured / tokushima_bed * 100;
    let tokushima_result_output = (Math.round(tokushima_result * 10)) / 10;

    tokushima_tight.innerHTML = tokushima_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (tokushima_result_output >= 80){
        tokushima_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (tokushima_result_output >= 95){
        tokushima_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

kagawa_bed.addEventListener("change",function(){

    let kagawa_injured = document.getElementById("kagawa_injured").value;
    let kagawa_bed = document.getElementById("kagawa_bed").value;
    let kagawa_tight = document.getElementById("kagawa_tight");

    let kagawa_result = kagawa_injured / kagawa_bed * 100;
    let kagawa_result_output = (Math.round(kagawa_result * 10)) / 10;

    kagawa_tight.innerHTML = kagawa_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (kagawa_result_output >= 80){
        kagawa_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (kagawa_result_output >= 95){
        kagawa_tight.style.color = '#ff0000';
        bgm2.play();
    }

});

ehime_bed.addEventListener("change",function(){

    let ehime_injured = document.getElementById("ehime_injured").value;
    let ehime_bed = document.getElementById("ehime_bed").value;
    let ehime_tight = document.getElementById("ehime_tight");

    let ehime_result = ehime_injured / ehime_bed * 100;
    let ehime_result_output = (Math.round(ehime_result * 10)) / 10;

    ehime_tight.innerHTML = ehime_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (ehime_result_output >= 80){
        ehime_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (ehime_result_output >= 95){
        ehime_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

kochi_bed.addEventListener("change",function(){

    let kochi_injured = document.getElementById("kochi_injured").value;
    let kochi_bed = document.getElementById("kochi_bed").value;
    let kochi_tight = document.getElementById("kochi_tight");

    let kochi_result = kochi_injured / kochi_bed * 100;
    let kochi_result_output = (Math.round(kochi_result * 10)) / 10;

    kochi_tight.innerHTML = kochi_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (kochi_result_output >= 80){
        kochi_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (kochi_result_output >= 95){
        kochi_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

fukuoka_bed.addEventListener("change",function(){

    let fukuoka_injured = document.getElementById("fukuoka_injured").value;
    let fukuoka_bed = document.getElementById("fukuoka_bed").value;
    let fukuoka_tight = document.getElementById("fukuoka_tight");

    let fukuoka_result = fukuoka_injured / fukuoka_bed * 100;
    let fukuoka_result_output = (Math.round(fukuoka_result * 10)) / 10;

    fukuoka_tight.innerHTML = fukuoka_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (fukuoka_result_output >= 80){
        fukuoka_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (fukuoka_result_output >= 95){
        fukuoka_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

saga_bed.addEventListener("change",function(){

    let saga_injured = document.getElementById("saga_injured").value;
    let saga_bed = document.getElementById("saga_bed").value;
    let saga_tight = document.getElementById("saga_tight");

    let saga_result = saga_injured / saga_bed * 100;
    let saga_result_output = (Math.round(saga_result * 10)) / 10;

    saga_tight.innerHTML = saga_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (saga_result_output >= 80){
        saga_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (saga_result_output >= 95){
        saga_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

nagasaki_bed.addEventListener("change",function(){

    let nagasaki_injured = document.getElementById("nagasaki_injured").value;
    let nagasaki_bed = document.getElementById("nagasaki_bed").value;
    let nagasaki_tight = document.getElementById("nagasaki_tight");

    let nagasaki_result = nagasaki_injured / nagasaki_bed * 100;
    let nagasaki_result_output = (Math.round(nagasaki_result * 10)) / 10;

    nagasaki_tight.innerHTML = nagasaki_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (nagasaki_result_output >= 80){
        nagasaki_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (nagasaki_result_output >= 95){
        nagasaki_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

kumamoto_bed.addEventListener("change",function(){

    let kumamoto_injured = document.getElementById("kumamoto_injured").value;
    let kumamoto_bed = document.getElementById("kumamoto_bed").value;
    let kumamoto_tight = document.getElementById("kumamoto_tight");

    let kumamoto_result = kumamoto_injured / kumamoto_bed * 100;
    let kumamoto_result_output = (Math.round(kumamoto_result * 10)) / 10;

    kumamoto_tight.innerHTML = kumamoto_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (kumamoto_result_output >= 80){
        kumamoto_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (kumamoto_result_output >= 95){
        kumamoto_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

oita_bed.addEventListener("change",function(){

    let oita_injured = document.getElementById("oita_injured").value;
    let oita_bed = document.getElementById("oita_bed").value;
    let oita_tight = document.getElementById("oita_tight");

    let oita_result = oita_injured / oita_bed * 100;
    let oita_result_output = (Math.round(oita_result * 10)) / 10;

    oita_tight.innerHTML = oita_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (oita_result_output >= 80){
        oita_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (oita_result_output >= 95){
        oita_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

miyazaki_bed.addEventListener("change",function(){

    let miyazaki_injured = document.getElementById("miyazaki_injured").value;
    let miyazaki_bed = document.getElementById("miyazaki_bed").value;
    let miyazaki_tight = document.getElementById("miyazaki_tight");

    let miyazaki_result = miyazaki_injured / miyazaki_bed * 100;
    let miyazaki_result_output = (Math.round(miyazaki_result * 10)) / 10;

    miyazaki_tight.innerHTML = miyazaki_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (miyazaki_result_output >= 80){
        miyazaki_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (miyazaki_result_output >= 95){
        miyazaki_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

kagoshima_bed.addEventListener("change",function(){

    let kagoshima_injured = document.getElementById("kagoshima_injured").value;
    let kagoshima_bed = document.getElementById("kagoshima_bed").value;
    let kagoshima_tight = document.getElementById("kagoshima_tight");

    let kagoshima_result = kagoshima_injured / kagoshima_bed * 100;
    let kagoshima_result_output = (Math.round(kagoshima_result * 10)) / 10;

    kagoshima_tight.innerHTML = kagoshima_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (kagoshima_result_output >= 80){
        kagoshima_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (kagoshima_result_output >= 95){
        kagoshima_tight.style.color = '#ff0000';
        bgm2.play();
    }
});

okinawa_bed.addEventListener("change",function(){

    let okinawa_injured = document.getElementById("okinawa_injured").value;
    let okinawa_bed = document.getElementById("okinawa_bed").value;
    let okinawa_tight = document.getElementById("okinawa_tight");

    let okinawa_result = okinawa_injured / okinawa_bed * 100;
    let okinawa_result_output = (Math.round(okinawa_result * 10)) / 10;

    okinawa_tight.innerHTML = okinawa_result_output + '%';
    let bgm = document.querySelector("#sound1");
    let bgm2 = document.querySelector("#sound2");

    if (okinawa_result_output >= 80){
        okinawa_tight.style.color = '#ff0000';
        bgm.play();
    }

    if (okinawa_result_output >= 95){
        okinawa_tight.style.color = '#ff0000';
        bgm2.play();
    }
});
