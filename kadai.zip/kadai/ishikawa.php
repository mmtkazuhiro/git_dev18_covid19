<?php

require_once('funcs.php');

$pdo = db_conn();
$stmt = $pdo->prepare("SELECT * FROM gs_c_table");
$status = $stmt->execute();

$view="";
if ($status==false) {
    sql_error($status);
}else{
    while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){

        $view .=
    '<tr>'.
        '<td>'.
        '<a href= "detail_ishikawa.php?id=' .$result['id'] .'">'.
            h($result['indate']).
        '</a>'.
        '</td>'.

        '<td>'.
            h($result['ishikawa_infected']) .
        '</td>'.

        '<td>'.
            h($result['ishikawa_injured']) .
        '</td>'.

        '<td>'.
            h($result['ishikawa_bed']) .
        '</td>'.
    '</tr>';

    
}
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/pref.css" rel="stylesheet">
    <title>石川県 過去データ一覧</title>
</head>
<body>
    <div class="title">石川県の過去データ一覧</div>
    <div class="exp">登録日時をクリックすることで詳細画面へ遷移します</div>

    <div class="return">
        <div class="outcovid"><a href="covid.php" class="return_covid">←登録へ戻る</a></div>　　　　　　　　
        <div class="outselect"><a href="select.php" class="return_select">←現在のコロナ感染者数へ戻る</a></div>
    </div>

    <table class="table">
        <tr>
        <th class="date">登録日時</th>
        <th class="infec">感染者数</th>
        <th class="inj">重傷者数</th>
        <th class="bed">病床数</th>
        </tr>
        <?= $view; ?>
    </table>





</body>
</html>