<?php

require_once('funcs.php');

//1. POSTデータ取得
    $fukushima_infected = $_POST['fukushima_infected'];
    $fukushima_injured = $_POST['fukushima_injured'];
    $fukushima_bed = $_POST['fukushima_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        fukushima_infected = :fukushima_infected,
                        fukushima_injured = :fukushima_injured,
                        fukushima_bed = :fukushima_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':fukushima_infected', $fukushima_infected, PDO::PARAM_INT); 
$stmt->bindValue(':fukushima_injured', $fukushima_injured, PDO::PARAM_INT);
$stmt->bindValue(':fukushima_bed', $fukushima_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('fukushima.php');
}
