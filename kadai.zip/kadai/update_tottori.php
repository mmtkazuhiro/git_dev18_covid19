<?php

require_once('funcs.php');

//1. POSTデータ取得
    $tottori_infected = $_POST['tottori_infected'];
    $tottori_injured = $_POST['tottori_injured'];
    $tottori_bed = $_POST['tottori_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        tottori_infected = :tottori_infected,
                        tottori_injured = :tottori_injured,
                        tottori_bed = :tottori_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':tottori_infected', $tottori_infected, PDO::PARAM_INT); 
$stmt->bindValue(':tottori_injured', $tottori_injured, PDO::PARAM_INT);
$stmt->bindValue(':tottori_bed', $tottori_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('tottori.php');
}
